﻿速递易开放平台服务软件开发工具包Java版
Sudiyi Open Platform SDK for Java

http://open.sudiyi.cn

环境要求：
- JDK1.6或以上
- jackson2.6.3,httpclient4.5等第三方软件包.(已包含在lib目录下)
- 必须注册有http://open.sudiyi.cn账户,并且已经获得了Access Id/Access Key

0.0.2更新日志：
1）增加"获取死信"接口.
2）"发起预约"接口增加description字段.

0.0.3更新日志:
1）为"取消预约"接口添加了返回值.
2）新增"获取箱格状态和在线状态"接口.
3）新增"获取附近设备"接口.
4）调整了SDK"请求"和"响应"实体的包结构.